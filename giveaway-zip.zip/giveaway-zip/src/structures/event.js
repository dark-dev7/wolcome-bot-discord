module.exports = class event{
    constructor(name){
        this.name = name;
    }
}