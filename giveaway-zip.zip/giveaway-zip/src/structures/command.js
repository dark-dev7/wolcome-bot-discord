module.exports = class command{
    constructor(name,aliases){
        this.name = name;
        this.aliases = aliases;
    }
}